# Flujo Vida

- Captar datos mínimos.
- Enviar a CRM.
- Derivar a cotizador o asesor.
