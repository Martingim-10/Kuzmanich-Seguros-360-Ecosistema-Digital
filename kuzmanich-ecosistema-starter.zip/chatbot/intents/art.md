# Flujo Art

- Captar datos mínimos.
- Enviar a CRM.
- Derivar a cotizador o asesor.
