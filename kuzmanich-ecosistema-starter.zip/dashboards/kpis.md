# KPIs — Kuzmanich Seguros 360

- Leads por ramo y canal
- Tasa de conversión por etapa
- Tiempo medio a cotización
- % Renovaciones y retención
- Ticket medio / prima promedio
- Ranking de asesores
