# Operativa y Normas

- Privacidad y consentimiento de datos.
- Respuesta en < 2 horas hábiles a leads calientes.
- Versionado semántico y PRs en GitHub.
- Backups semanales de Sheets.
