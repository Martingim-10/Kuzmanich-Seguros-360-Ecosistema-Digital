# Branding — Kuzmanich Seguros 360

## Colores
- Azul corporativo: #0056FF
- Grafito: #0A1428
- Gris metálico: #A0A5AD
- Dorado (Retiro): #FFD166
- Verde (Salud): #4CAF50
- Rojo (Vida): #F44336
- Naranja (Pyme): #FF9800
- Celeste (Hogar): #2196F3
- Violeta (Viaje): #7E57C2

## Tipografías
- Titulares: Montserrat
- Texto: Poppins
